/*

Heman Baral
CMSC 401 
Assignment 3

Finding the best roadtrip route form one city to another


*/





import java.util.*;
import java.util.ArrayList;





 class MinimumHeap {

    private ArrayList<graphNode> array;

    protected int size;

    private Map<Integer,Integer> graphNodeIndex = new HashMap();
    
	public MinimumHeap () {

        array = new ArrayList<graphNode>();  

        size = 0;
    }
    

    public void add(graphNode node) {

    array.add(node);

	graphNodeIndex.put(node.getCity(), size);

	size++;

        maxHeap();
    }
    
 
    public boolean isEmpty() {
        return size == 0;
    }


public boolean hasCity(int key){

        return graphNodeIndex.containsKey(key);
    }
 
    public graphNode look() {

        if (this.isEmpty()) {

            throw new IllegalStateException();
        }
        
        return array.get(0);
    }

    
  
    public graphNode remove() {
    	
    	graphNode result = look();

	graphNodeIndex.remove(array.get(0).getCity());

        graphNodeIndex.put(array.get(size - 1).getCity(), 0);
    	
    	array.set(0, array.get(size - 1));

	array.remove(size - 1);

    	size--;
    	
    	minHeap();
    	
    	return result;
    }
    

    public void print() {

    	for (int i = 0; i < size; i++) {

		graphNode temp = array.get(i);

		System.out.printf("%d\n ", temp.getCost());
        System.out.printf("%d\n",temp.getCity());

	}   
    }

    
    
    protected void minHeap() {

        int index = 0;
      
        while (hasLeftChild(index)) {

            int sChild = leftIndex(index);
            
            
            if (hasRightChild(index)

       && array.get(leftIndex(index)).compareNode(array.get(rightIndex(index))) > 0) {

                sChild = rightIndex(index);
            } 
            
            if (array.get(index).compareNode(array.get(sChild)) > 0) {
                swap(index, sChild);

            } else {
               
                break;
            }
            
           
            index = sChild;
        }        
    }
    
    
   
    protected void maxHeap() {

        int index = this.size - 1;
        
        while (hasParent(index) && (parent(index).compareNode(array.get(index)) > 0)) {

            swap(index, parentIndex(index));

            index = parentIndex(index);
        }        
    }
    
    public void printIndex(){

        System.out.println(graphNodeIndex);
    }

public void changeCost(int cNode, int Cost) {

	int index = graphNodeIndex.get(cNode);

	graphNode temp = array.get(index);

	temp.setCost(Cost);

	array.set(index, temp);
	
	while (hasParent(index) && (parent(index).compareNode(array.get(index)) > 0)) {

            
            swap(index, parentIndex(index));

            index = parentIndex(index);
        }  

	while (hasLeftChild(index)) {
         
            int sChild = leftIndex(index);
            
           
            if (hasRightChild(index)

       && array.get(leftIndex(index)).compareNode(array.get(rightIndex(index))) > 0) {

                sChild = rightIndex(index);
            } 
            
            if (array.get(index).compareNode(array.get(sChild)) > 0) {
                swap(index, sChild);

            } else {
                
                break;
            }
            
           
            index = sChild;
        }   
   

}
public Integer getCost(Integer cNode) {

        Integer index = graphNodeIndex.get(cNode);

        if( index == null ) {

            return null;
        } 
	else {
            return array.get(index).getCost();
        }
}

	
  
    protected boolean hasParent(int a) {
        return a > 0;
    }
  
    
    protected int leftIndex(int a) {
        return a * 2 + 1;
    }
   
   
    protected int rightIndex(int a) {    
        return a * 2 + 2;
    }
    
    
    protected boolean hasLeftChild(int a) {
        return leftIndex(a) < size;
    }
    
    
    protected boolean hasRightChild(int a) {
        return rightIndex(a) < size;
    }
    
    
    protected graphNode parent(int a) {
        return array.get(parentIndex(a));
    }
    
    
    protected int parentIndex(int a) {      
        return (a - 1) / 2;	             
    }					      
    
    
    protected void swap(int in1, int in2) {

        graphNode temp = array.get(in1);

	int initialCitytin1 = temp.getCity();

	int initialCitytin2 = array.get(in2).getCity();

	graphNodeIndex.put(initialCitytin1, in2);

        graphNodeIndex.put(initialCitytin2, in1);

        array.set(in1, array.get(in2));

        array.set(in2, temp);        
    }
        
 public int getSize() {

	return size;
}

}







     class graphNode {
         
        private int cNode;
        private int Cost;
                
        public graphNode(int cNode, int Cost) {
            this.cNode = cNode;
            this.Cost = Cost;
        }

        public int getCost() {
            return Cost;
        }

        public void setCost(int Cost) {
            this.Cost = Cost;
        }

        public int getCity() {
            return cNode;
        }

        public int compareNode(graphNode node) {
            int num = 0;
            if(this.Cost > node.getCost() ) {
                num = 1;
            }
            else if (this.Cost < node.getCost() ) {
                num = -1;
            }

            return num;
        }
    }









    public class cmsc401 {
    
    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);

        int N = in.nextInt();   

        int M = in.nextInt();       


        Map<Integer,Integer> motelCost = new HashMap(N-2);

        Map<Integer,ArrayList<int[]>> cities = new HashMap(M);

        Map<Integer,Integer> cPath = new HashMap();  

        Integer motels = 0;
        
        motelCost.put(2,0);

        for (int i = 0; i < N - 2; i++) {

            motels = in.nextInt();

            motelCost.put(motels, in.nextInt());
        }
        
        int initialCity = 0;

        int finalCity = 0;

        int gasCost = 0;

        for (int i = 0; i < M; i++) {

            initialCity = in.nextInt();

            finalCity = in.nextInt();

            gasCost = in.nextInt();
            

            int[] first = { finalCity, gasCost };

            if(cities.get(initialCity) == null) {

                ArrayList<int[]> t1 = new ArrayList<int[]>();

                t1.add(first);

                cities.put(initialCity, t1);
            }
            else {
                ArrayList<int[]> t2 = cities.get(initialCity);

                t2.add(first);

                cities.put(initialCity, t2);
            }
            

            int[] last = { initialCity, gasCost };

            if(cities.get(finalCity) == null) {

                ArrayList<int[]> temp3 = new ArrayList<int[]>();

                temp3.add(last);

                cities.put(finalCity, temp3);
            }
            else {

                ArrayList<int[]> temp4 = cities.get(finalCity);

                temp4.add(last);

                cities.put(finalCity, temp4);
            }
        }

    MinimumHeap cityHeap = new MinimumHeap();

    for (int i = 2; i < N + 1; i++) {

        cityHeap.add(new graphNode(i, Integer.MAX_VALUE));
    }

    int[] c1 = {1,0};

    cPath.put(1,0);

    Integer nextNode = c1[0];

    while(cityHeap.getSize() > 0) {

        ArrayList<int[]> adjCities = cities.get(nextNode);

        for(int i = 0; i < adjCities.size(); i++) {

            int[] adjCity = adjCities.get(i);

            if(!cityHeap.hasCity(adjCity[0])) {

                continue;
            }

            int Cost = cPath.get(nextNode) + adjCity[1] + motelCost.get(adjCity[0]);

            if (Cost < cityHeap.getCost(adjCity[0]) ) {

                cityHeap.changeCost(adjCity[0], Cost);
            }
            
        }

        graphNode node = cityHeap.remove();

        cPath.put(node.getCity(), node.getCost());

        nextNode = node.getCity();

        if (nextNode == 2 ) {

            System.out.println(cPath.get(nextNode));

            break;
        }
    }
}
}